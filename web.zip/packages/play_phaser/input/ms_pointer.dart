part of Phaser;

class MSPointer {
  MSPointer() {
  }
}
