part of Phaser;

class GamepadButton {
  GamepadButton() {
  }
}
