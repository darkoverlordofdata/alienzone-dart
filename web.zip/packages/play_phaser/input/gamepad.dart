part of Phaser;

class Gamepad {
  Gamepad() {
  }
}
