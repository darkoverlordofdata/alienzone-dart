part of Phaser;

class SinglePad {
  SinglePad() {
  }
}
